/**
 * 
 */
package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;

import app.RePrExWebService;

/**
 * Test cases for Revel Practical Exercise Web Service class
 * 
 * @author Vern Reinhardt
 */
public class RePrExWebServiceTest {

	final String JSON_EXAMPLE_FILE = "examplefile.json";
	RePrExWebService rpews = null;
	
	@Before
	public void setup() {
		rpews = new RePrExWebService();
	}

	@Test
	public void testGetFiveDayForecast() {

		// Make sure the correct number of forecast elements appears
		// (5 days X 8 elements/day)
		String result = rpews.getFiveDayForecast();
		int elementCnt = StringUtils.countMatches(result, "temp_max");
		int indexOfCnt = StringUtils.indexOf(result, "cnt");
		String cntStr = StringUtils.substring(result, indexOfCnt + 5, indexOfCnt + 7);
//		System.out.println("cntStr: " + cntStr);
		assertEquals("Number of forecast elements claimed in " + result.length()
			+ " character string: ", Integer.parseInt(cntStr), elementCnt);
	}

	@Test
	public void testFindDateAndTempInForecastEmpty() {

		String forecast = null;

		Map<String, String> results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Null imput string should return empty map ", results);

		forecast = "";
		results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Empty imput string should return empty map ", results);

		forecast = " 	"; 
		results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Whitespace imput string should return empty map ", results);
	}

	@Test
	public void testFindDateWthrTempInForecastString() {

		String forecast = "";
		try {
			forecast = new String(Files.readAllBytes(Paths.get(JSON_EXAMPLE_FILE)));
		} catch (IOException e) {
			System.out.println("IO Exception encountered in test case setup: ");
			e.printStackTrace();
		}
//		System.out.println("testFindDateAndTempInForecastString: forecast: " + forecast);

		Map<String, String> results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Null imput string should return empty map ", results);

		forecast = "";
		results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Empty imput string should return empty map ", results);

		forecast = " 	"; 
		results = rpews.findDateWthrTempInForecast(forecast);
		assertNotNull("Whitespace imput string should return empty map ", results);
	}
}
