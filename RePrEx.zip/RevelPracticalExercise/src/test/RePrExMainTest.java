/**
 * 
 */
package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import app.RePrExMain;

/**
 * Test cases for Revel Practical Exercise Main class
 * 
 * @author Vern Reinhardt
 */
public class RePrExMainTest {

	RePrExMain rpem = null;
	
	@Before
	public void setup() {
		rpem = new RePrExMain();
	}

	@Test
	public void testSelectContactMethod() {

		// Test phone call cases
		String result = rpem.selectContactMethod("rain", "65.1");
		assertEquals("Contact should be via phone call ", result, RePrExMain.CONTACT_METHOD_PHONE_CALL);

		result = rpem.selectContactMethod("rain", "54.9");
		assertEquals("Contact should be via phone call ", result, RePrExMain.CONTACT_METHOD_PHONE_CALL);

		result = rpem.selectContactMethod("anything", "54.9");
		assertEquals("Contact should be via phone call ", result, RePrExMain.CONTACT_METHOD_PHONE_CALL);

		// Test e-mail cases
		result = rpem.selectContactMethod("snow", "55.0");
		assertEquals("Contact should be via e-mail ", result, RePrExMain.CONTACT_METHOD_EMAIL);

		result = rpem.selectContactMethod("snow", "55.1");
		assertEquals("Contact should be via e-mail ", result, RePrExMain.CONTACT_METHOD_EMAIL);

		result = rpem.selectContactMethod("cloudy", "75.0");
		assertEquals("Contact should be via e-mail ", result, RePrExMain.CONTACT_METHOD_EMAIL);

		// Test text message cases
		result = rpem.selectContactMethod("cloudy", "75.1");
		assertEquals("Contact should be via text message ", result, RePrExMain.CONTACT_METHOD_TEXT_MESSAGE);

		result = rpem.selectContactMethod("sunny", "75.1");
		assertEquals("Contact should be via text message ", result, RePrExMain.CONTACT_METHOD_TEXT_MESSAGE);

		result = rpem.selectContactMethod("windy", "101.1");
		assertEquals("Contact should be via text message ", result, RePrExMain.CONTACT_METHOD_TEXT_MESSAGE);
	}
}
