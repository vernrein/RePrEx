/**
 * 
 */
package app;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * Revel Practical Exercise Web Service class
 * Class of an OpenWeather RESTful web service used to retrieve a JSON string
 * which contains a five-day forecast for a particular city.
 * 
 * @author Vern Reinhardt
 */
public class RePrExWebService {

	private static final String OPEN_WEATHER_URI =
			"http://api.openweathermap.org/data/2.5/forecast?q=minneapolis,us&units=imperial&APPID=09110e603c1d5c272f94f64305c09436";

	/**
	 * Method to use the HTTP POST method to retrieve a five-day forecast for
	 * the city of interest (Minneapolis, MN, USA) and return the forecast's 
	 * JSON values in a collection.
	 */
	public String getFiveDayForecast() {

		HttpClient httpclient;
        HttpEntity entity = null;
        String strJSON = "";

        try {
        	// Create a new client and give it a default configuration
			httpclient = HttpClients.createDefault();
			URIBuilder builder = new URIBuilder(OPEN_WEATHER_URI);

			// Build a new POST request and configure its URI
			URI uri = builder.build();
			HttpPost request = new HttpPost(uri);
			
			// Empty the request body for the POST method
            StringEntity reqEntity = new StringEntity("");
            request.setEntity(reqEntity);

            // Execute the request and return the JSON string in the response
            HttpResponse response = httpclient.execute(request);
            entity = response.getEntity();

            if (entity == null) {
//                System.out.println("RePrExWebService: getFiveDayForecast(): "
//                        + "Null response value for entity indicates a JSON "
//                		+ "retrieval problem.");
            } else {
                strJSON = EntityUtils.toString(entity);
//                System.out.println("RePrExWebService: getFiveDayForecast(): "
//                		+ "Forecast retrieved successfully");
            }

		} catch (URISyntaxException | IOException exc) {
            exc.printStackTrace();
		}

//        System.out.println("RePrExWebService: getFiveDayForecast(): " + strJSON);
        return strJSON;
	}

	/**
	 * Method to scan the JSON string, find the max temperature and text date
	 * in each element and use those to create a map that is returned.
	 * @param jsonStr Response string from the weather forecast site
	 * @return Map of the max temperature and text date in each element 
	 */
	public Map<String, String> findDateWthrTempInForecast(String jsonStr) {

		HashMap<String, String> dateTempMap = new HashMap<String, String>();

		// Fail fast if string is null, empty or whitespace.
		if (StringUtils.isBlank((CharSequence)jsonStr)) {
//			System.out.println("RePrExWebService: findDateWthrTempInForecast(): "
//					+ "Input string must not be null, empty or all whitespace.");
			return dateTempMap;
		}

		// Continue to process if string contains any valid data.
		else {
		// TODO: There should be a way to do this using JSON nodes and avoiding
			// the pitfalls of String parsing.  However, once I started down
			// the Strings path, I was unwilling to throw it all away and begin
			// from scratch with tree maps and nodes.

			// Find each maximum temp and its associated date and time
			// Use String functions to find the element count (probably 40)
			int indexOfCnt = StringUtils.indexOf(jsonStr, "cnt");
			int indexOfColon = StringUtils.indexOf(jsonStr, ":", indexOfCnt);
			int indexOfComma = StringUtils.indexOf(jsonStr, ",", indexOfCnt);
			String cntStr = StringUtils.substring(jsonStr, indexOfColon + 1, indexOfComma);
			// Strip any leading or trailing colons, double quotes, commas, or
			// spaces before converting the count string to an integer.
			int elemCnt = Integer.parseInt(StringUtils.strip(cntStr, " :\","));
//			System.out.println("RePrExWebService: findDateWthrTempInForecast(): elemCnt: " + elemCnt);

			// Use String functions to find the dates, weather, and temps
			String locStr = jsonStr;
			for (int i = 1; i <= elemCnt; i++) {
				// Get the next max temp index, retrieve the temperature
				// string, and save it as a decimal number.
				int indexOfTempMax = StringUtils.ordinalIndexOf(locStr, "temp_max", i);
				indexOfColon = StringUtils.indexOf(locStr, ":", indexOfTempMax);
				indexOfComma = StringUtils.indexOf(locStr, ",", indexOfTempMax);
				// Strip any leading or trailing colons, double quotes, commas, or
				// spaces before converting the count string to an integer.
				String tempMaxStr = StringUtils.strip(
						StringUtils.substring(locStr, indexOfColon + 1, indexOfComma), " :\",");
//				System.out.println("RePrExWebService: findDateAndTempInForecast(" 
//						+ i + "): tempMaxStr: " + tempMaxStr);
				BigDecimal tempMax = new BigDecimal(StringUtils.strip(tempMaxStr, " :\","));
//				System.out.println("RePrExWebService: findDateAndTempInForecast(" 
//						+ i + "): temp_max: " + tempMax);

				// Get the next weather main index, and retrieve the weather
				// Each element has two "main" tags, so look at every other one
				int indexOfWthrMain = StringUtils.ordinalIndexOf(locStr, "main", i * 2);
				indexOfColon = StringUtils.indexOf(locStr, ":", indexOfWthrMain);
				indexOfComma = StringUtils.indexOf(locStr, ",", indexOfWthrMain);
				String mainWthrStr = StringUtils.strip(
						StringUtils.substring(locStr, indexOfColon + 1, indexOfComma), " :\",");
//				System.out.println("RePrExWebService: findDateWthrTempInForecast(" 
//						+ i + "): " + mainWthrStr);

				// Get the next text date index, and retrieve the date and
				// hour. This field has no closing comma.
				int indexOfDtTxt = StringUtils.ordinalIndexOf(locStr, "dt_txt", i);
				indexOfColon = StringUtils.indexOf(locStr, ":", indexOfDtTxt);
				String dtTxtStr = StringUtils.strip(
						StringUtils.substring(locStr, indexOfColon + 1, indexOfColon + 16), " :\",");
//				System.out.println("RePrExWebService: findDateAndTempInForecast(" 
//						+ i + "): dt_txt: " + dtTxtStr);

				// If the time is for the noon hour, save the date and 
				// weather|temperature.
				if ((StringUtils.trim(StringUtils.substring(dtTxtStr, -2)).equals("12"))) {
					dateTempMap.put(StringUtils.trim(StringUtils.substring(dtTxtStr, 0, -2)), 
							StringUtils.lowerCase(mainWthrStr) + "|" + tempMax.toString());
				}
			}
		}

		Map<String, String> treeMap = new TreeMap<String, String>(dateTempMap);
//		System.out.println("RePrExWebService: findDateAndTempInForecast: treeMap: "
//				+ treeMap.toString());
		return treeMap;
	}
}
