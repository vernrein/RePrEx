/**
 * 
 */
package app;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

/**
 * Revel Practical Exercise Main class
 * 
 * @author Vern Reinhardt
 */
public class RePrExMain {

	public static final String CONTACT_METHOD_EMAIL = "e-mail";
	public static final String CONTACT_METHOD_PHONE_CALL = "phone call";
	public static final String CONTACT_METHOD_TEXT_MESSAGE = "text message";

	/**
	 * Main method for running the exercise.
	 * 
	 * @param args
	 *            Not used
	 */
	public static void main(String[] args) {

		RePrExMain rpem = new RePrExMain();
//		System.out.println("RePrExMain: main(): Enter");
		RePrExWebService rpews = new RePrExWebService();

		String forecastStr = rpews.getFiveDayForecast();
		Map<String, String> dataMap = rpews.findDateWthrTempInForecast(forecastStr);

		// Print the temperature, date, and contact method to the console
		Set<String> keySet = dataMap.keySet();
//		System.out.println("RePrExMain: main: keySet: " + keySet.toString()); 
	 
	    // Display elements as required
		for (String key: keySet) {
			String mapValue = dataMap.get(key);
			String mapWthr = mapValue.substring(0, StringUtils.indexOf(mapValue, "|"));
			String mapTemp = mapValue.substring(StringUtils.indexOf(mapValue, "|") + 1);
			String contactMethod = rpem.selectContactMethod(mapWthr, mapTemp);
			System.out.println("Date: " + key + " Contact via: " + contactMethod);
	    }
	}

	/**
	 * Method to take the two data points of significance and, based on the rules
	 * expressed in the requirements document, return a contact method.
	 * <ul>
	 * <li>Engage customer via text message when forecast is for sunny sky and
	 * temperature warmer than 75F</li>
	 * <li>Engage customer via email when forecast is for temperature between 55F
	 * and 75F (inclusive)</li>
	 * <li>Engage customer via phone call when forecast is for rain or temperature
	 * less than 55F</li>
	 * </ul>
	 * 
	 * @param noonWthr String containing weather forecast for noon of the day
	 * of interest, may be "rain", "clouds", "snow", "sunny", etc.
	 * @param noonTemp Fahrenheit temperature forecast for noon of the day
	 * of interest, may be negative
	 */
	public String selectContactMethod(String noonWthr, String noonTemp) {

		// Convert the incoming temperature string to a BigDecimal
		BigDecimal decimalTemp = null;
		final BigDecimal decimal55 = new BigDecimal("55.0");
		final BigDecimal decimal75 = new BigDecimal("75.0");

		try {
			decimalTemp = new BigDecimal(noonTemp);
		} catch (NumberFormatException e) {
			System.out.println("RePrExMain: selectContactMethod(): "
					+ "Temperature value formatted incorrectly:\n");
			e.printStackTrace();
		}

		// Check the sky value for 'rain'; all others are considered 'sunny'.
		if (StringUtils.isNotBlank(noonWthr) && noonWthr.equals("rain")) {
//			System.out.println("\nRePrExMain: selectContactMethod(): rainy weather");
			return CONTACT_METHOD_PHONE_CALL;
		}

		// Check the temperature for <55F.
		else if (StringUtils.isNotBlank(noonTemp) && (decimalTemp.compareTo(decimal55)) == -1) {
//			System.out.println("\nRePrExMain: selectContactMethod(): temp below 55F");
			return CONTACT_METHOD_PHONE_CALL;
		}

		// Check the temperature value for <=75F and >=55F.
		else if (StringUtils.isNotBlank(noonTemp) && ((decimalTemp.compareTo(decimal55)) >= 0)
				&& ((decimalTemp.compareTo(decimal75)) <= 0)) {
//			System.out.println("\nRePrExMain: selectContactMethod(): temp between 55 and 75F");
			return CONTACT_METHOD_EMAIL;
		}

		else {
//			System.out.println("\nRePrExMain: selectContactMethod(): default weather");
			return CONTACT_METHOD_TEXT_MESSAGE;
		}
	}
}
